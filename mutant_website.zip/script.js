function showPower() {
  alert("🧬 Mutation Activated!");
}
