# 🧬 MutantX Website

A mutant-themed website project for GitHub.

## Features
- Dark sci-fi UI
- Mutant character section
- Interactive JavaScript button
- Clean layout

## How to Run
Open `index.html` in your browser.

## Author
Created for GitHub project practice.
